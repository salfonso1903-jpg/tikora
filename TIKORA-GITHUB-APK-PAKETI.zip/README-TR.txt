TIKORA - TEK KAYNAK PAKETI
==========================

Bu paket TIKORA'nin mevcut web/Capacitor kaynaklarini ve Supabase kurulum SQL dosyalarini bir araya getirir. Instagram'in kapali/telifli kaynak kodu degildir.

PAKETTE
- www/index.html, app.js, style.css, config.js: uygulama kaynaklari
- supabase/00-stories-storage.sql: hikaye tablosu ve medya bucket kurulumu
- supabase/01-social-features.sql: mesaj, arkadas istegi, engelleme, kaydedilenler, bildirim, rapor, goruntulenme, arama/canli yayin metadata tabloları
- .github/workflows/build-apk.yml: APK derleme akisi
- package.json ve capacitor.config.json: Capacitor proje ayarlari

KURULUM
1) ZIP'i cikart.
2) Supabase Dashboard > SQL Editor bolumunde once supabase/00-stories-storage.sql, sonra supabase/01-social-features.sql dosyalarinin tamamini ayri sorgular olarak calistir.
3) GitHub deposundaki www klasorunu paketteki www klasoruyle degistir. package.json, capacitor.config.json ve .github klasorlerini de depo kokune kopyala.
4) GitHub Actions'tan APK derlemesini baslat.
5) Supabase Authentication > URL Configuration icinde uygulamanin dogru geri donus adreslerini ayarla. Telefon OTP icin Authentication > Providers > Phone altinda SMS saglayicisi gerekir.

ONEMLI VERITABANI NOTU
Uygulama mesajlarda recipient_id alanini kullanir. SQL dosyasi da recipient_id kullanir; receiver_id ile karistirmayin. SQL dosyalari mevcut profiles, posts ve stories tablolarinin var oldugunu varsayar. Mevcut verileri silmez.

GERCEK OZELLIK DURUMU
Mevcut uygulama kaynaklarinda: e-posta/telefon OTP arayuzu, akis, gonderi, begeni, yorum, profil, takip, hikaye, video akisi, kesfet/arama, birebir metin mesajlasma, bildirim ekrani ve bazi hesap araclari bulunur.
Bu pakette SQL altyapisi eklenen ancak mevcut arayuzu tamamlanmamis ozellikler: arkadaslik istekleri, engelleme, kaydedilen gonderiler, raporlama, mesaj tepkileri, paylasim/goruntulenme kayitlari.
Sesli/goruntulu arama ve canli yayin icin yalnizca oturum/yayin metadata tabloları vardir. Gercek ses/video tasimasi icin ayri WebRTC/medya saglayicisi, sunucu anahtarlari ve istemci entegrasyonu gerekir; bu ZIP'te calisir arama veya canli yayin yoktur.
Push bildirimleri, gelismis Reels editoru, reklam yonetimi ve profesyonel analiz paneli de tamamlanmis degildir.

DOGRULAMA SINIRI
app.js JavaScript syntax kontrolunden gecirilmistir ve ZIP arsivi acilma kontrolu yapilmistir. Gercek Supabase projesinde SQL calistirma, iki farkli kullanici arasinda mesajlasma, APK'nin telefonda calismasi, SMS saglayicisi, ses/video servisi canli olarak test edilmemistir. Bu nedenle sifir hata garantisi verilmez.


EKLENEN BIRLESTIRME NOTLARI
- supabase/00-stories-storage.sql ve supabase/01-social-features.sql: Instagram tarzı sosyal özellik şemaları.
- supabase/02-safe-base.sql ve supabase/03-safe-upgrade.sql: önceki güvenli güncelleme paketindeki SQL dosyaları.
- scripts/prepare-emergent-env.sh: paylaşılan JWT_SECRET / ADMIN_EMAILS / memory klasörü hazırlama komutunun güvenli, tekrar çalıştırılabilir hali.
- .github/workflows/build-apk.yml: GitHub Actions üzerinden Android debug APK derleme iş akışı.

ÖNEMLİ SINIRLAR
- Bu arşivde Emergent'ten gönderilmiş ve erişilebilen paket dosyaları birleştirilmiştir. Sohbet mesajı olarak yapıştırılmış ancak tam kaynak metni bu çalışma alanında bulunmayan Python backend dosyaları (server.py, r_auth.py vb.) bu ZIP'e eklenmiş değildir.
- APK derlemesi GitHub Actions ortamında yapılır; bu ZIP'in içinde önceden derlenmiş APK yoktur.
- Supabase SQL dosyalarını sırayla uygulamadan ve proje URL/anahtar ayarlarını doğrulamadan canlı uygulama hazır sayılmaz.
- Supabase service_role anahtarını asla www/config.js içine koymayın. Yalnızca publishable/anon anahtarı istemci tarafında kullanılmalıdır.
