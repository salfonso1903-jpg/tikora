#!/usr/bin/env bash
set -euo pipefail
ENV_FILE="${1:-/app/backend/.env}"
mkdir -p "$(dirname "$ENV_FILE")" /app/memory
touch "$ENV_FILE"
if ! grep -q '^JWT_SECRET=' "$ENV_FILE"; then
  printf '\\nJWT_SECRET=%s\\n' "$(openssl rand -hex 32)" >> "$ENV_FILE"
fi
if ! grep -q '^ADMIN_EMAILS=' "$ENV_FILE"; then
  printf '\\nADMIN_EMAILS=admin@tikora.app\\n' >> "$ENV_FILE"
fi
echo "TIKORA backend environment prepared. Existing secrets were preserved."
