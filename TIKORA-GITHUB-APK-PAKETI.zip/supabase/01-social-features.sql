-- TIKORA additive migration. Existing user/content tables are not dropped.
create extension if not exists pgcrypto;

-- Direct messages: the app uses recipient_id (NOT receiver_id).
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  recipient_id uuid not null references auth.users(id) on delete cascade,
  body text not null default '',
  created_at timestamptz not null default now(),
  read_at timestamptz,
  constraint tikora_messages_not_self check (sender_id <> recipient_id)
);
alter table public.messages add column if not exists recipient_id uuid references auth.users(id) on delete cascade;
alter table public.messages add column if not exists body text not null default '';
alter table public.messages add column if not exists created_at timestamptz not null default now();
alter table public.messages add column if not exists read_at timestamptz;
create index if not exists tikora_messages_sender_time_idx on public.messages(sender_id, created_at desc);
create index if not exists tikora_messages_recipient_time_idx on public.messages(recipient_id, created_at desc);
alter table public.messages enable row level security;
drop policy if exists tikora_messages_select on public.messages;
create policy tikora_messages_select on public.messages for select to authenticated
using (sender_id = auth.uid() or recipient_id = auth.uid());
drop policy if exists tikora_messages_insert on public.messages;
create policy tikora_messages_insert on public.messages for insert to authenticated
with check (sender_id = auth.uid() and recipient_id <> auth.uid());
drop policy if exists tikora_messages_update_read on public.messages;
create policy tikora_messages_update_read on public.messages for update to authenticated
using (recipient_id = auth.uid()) with check (recipient_id = auth.uid());
grant select, insert, update on public.messages to authenticated;

create table if not exists public.friend_requests (
 id uuid primary key default gen_random_uuid(),
 sender_id uuid not null references auth.users(id) on delete cascade,
 receiver_id uuid not null references auth.users(id) on delete cascade,
 status text not null default 'pending' check (status in ('pending','accepted','rejected')),
 created_at timestamptz not null default now(),
 unique(sender_id, receiver_id), check(sender_id <> receiver_id)
);
create table if not exists public.blocks (
 blocker_id uuid not null references auth.users(id) on delete cascade,
 blocked_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now(),
 primary key(blocker_id, blocked_id), check(blocker_id <> blocked_id)
);
create table if not exists public.saved_posts (
 user_id uuid not null references auth.users(id) on delete cascade,
 post_id uuid not null references public.posts(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(user_id, post_id)
);
create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 actor_id uuid references auth.users(id) on delete set null,
 type text not null, reference_id uuid, is_read boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.user_settings (
 user_id uuid primary key references auth.users(id) on delete cascade,
 notifications_enabled boolean not null default true,
 private_account boolean not null default false,
 show_activity boolean not null default true,
 allow_messages boolean not null default true,
 updated_at timestamptz not null default now()
);
create table if not exists public.story_views (
 story_id uuid not null references public.stories(id) on delete cascade,
 viewer_id uuid not null references auth.users(id) on delete cascade,
 viewed_at timestamptz not null default now(), primary key(story_id, viewer_id)
);
create table if not exists public.reports (
 id uuid primary key default gen_random_uuid(),
 reporter_id uuid not null references auth.users(id) on delete cascade,
 reported_user_id uuid references auth.users(id) on delete cascade,
 post_id uuid references public.posts(id) on delete cascade,
 reason text not null, created_at timestamptz not null default now(),
 check(reported_user_id is not null or post_id is not null)
);
create table if not exists public.message_reactions (
 id uuid primary key default gen_random_uuid(),
 message_id uuid not null references public.messages(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 emoji text not null, created_at timestamptz not null default now(), unique(message_id,user_id)
);
create table if not exists public.post_shares (
 id uuid primary key default gen_random_uuid(),
 post_id uuid not null references public.posts(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.post_views (
 id uuid primary key default gen_random_uuid(),
 post_id uuid not null references public.posts(id) on delete cascade,
 user_id uuid references auth.users(id) on delete set null,
 viewed_at timestamptz not null default now()
);

-- Optional provider-backed features. These tables store metadata only; they do not provide media transport.
create table if not exists public.call_sessions (
 id uuid primary key default gen_random_uuid(),
 caller_id uuid not null references auth.users(id) on delete cascade,
 callee_id uuid not null references auth.users(id) on delete cascade,
 provider text not null,
 room_id text not null,
 status text not null default 'ringing' check(status in ('ringing','accepted','ended','missed','rejected')),
 created_at timestamptz not null default now(), ended_at timestamptz,
 check(caller_id <> callee_id)
);
create table if not exists public.live_streams (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 provider text not null,
 provider_stream_id text,
 playback_url text,
 title text,
 status text not null default 'scheduled' check(status in ('scheduled','live','ended')),
 created_at timestamptz not null default now(), ended_at timestamptz
);

-- Enable RLS on all new user data.
do $$ declare t text; begin
 foreach t in array array['friend_requests','blocks','saved_posts','notifications','user_settings','story_views','reports','message_reactions','post_shares','post_views','call_sessions','live_streams'] loop
  execute format('alter table public.%I enable row level security', t);
 end loop;
end $$;

-- Policies are deliberately owner/participant scoped.
drop policy if exists tikora_friend_select on public.friend_requests;
create policy tikora_friend_select on public.friend_requests for select to authenticated using(sender_id=auth.uid() or receiver_id=auth.uid());
drop policy if exists tikora_friend_insert on public.friend_requests;
create policy tikora_friend_insert on public.friend_requests for insert to authenticated with check(sender_id=auth.uid());
drop policy if exists tikora_friend_update on public.friend_requests;
create policy tikora_friend_update on public.friend_requests for update to authenticated using(receiver_id=auth.uid()) with check(receiver_id=auth.uid());
drop policy if exists tikora_blocks_owner on public.blocks;
create policy tikora_blocks_owner on public.blocks for all to authenticated using(blocker_id=auth.uid()) with check(blocker_id=auth.uid());
drop policy if exists tikora_saved_owner on public.saved_posts;
create policy tikora_saved_owner on public.saved_posts for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
drop policy if exists tikora_notifications_owner on public.notifications;
create policy tikora_notifications_owner on public.notifications for select to authenticated using(user_id=auth.uid());
drop policy if exists tikora_notifications_read on public.notifications;
create policy tikora_notifications_read on public.notifications for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
drop policy if exists tikora_settings_owner on public.user_settings;
create policy tikora_settings_owner on public.user_settings for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
drop policy if exists tikora_story_views_select on public.story_views;
create policy tikora_story_views_select on public.story_views for select to authenticated using(viewer_id=auth.uid() or exists(select 1 from public.stories s where s.id=story_id and s.user_id=auth.uid()));
drop policy if exists tikora_story_views_insert on public.story_views;
create policy tikora_story_views_insert on public.story_views for insert to authenticated with check(viewer_id=auth.uid());
drop policy if exists tikora_reports_insert on public.reports;
create policy tikora_reports_insert on public.reports for insert to authenticated with check(reporter_id=auth.uid());
drop policy if exists tikora_reports_select on public.reports;
create policy tikora_reports_select on public.reports for select to authenticated using(reporter_id=auth.uid());
drop policy if exists tikora_reactions_select on public.message_reactions;
create policy tikora_reactions_select on public.message_reactions for select to authenticated using(exists(select 1 from public.messages m where m.id=message_id and (m.sender_id=auth.uid() or m.recipient_id=auth.uid())));
drop policy if exists tikora_reactions_insert on public.message_reactions;
create policy tikora_reactions_insert on public.message_reactions for insert to authenticated with check(user_id=auth.uid() and exists(select 1 from public.messages m where m.id=message_id and (m.sender_id=auth.uid() or m.recipient_id=auth.uid())));
drop policy if exists tikora_reactions_delete on public.message_reactions;
create policy tikora_reactions_delete on public.message_reactions for delete to authenticated using(user_id=auth.uid());
drop policy if exists tikora_post_shares_owner on public.post_shares;
create policy tikora_post_shares_owner on public.post_shares for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
drop policy if exists tikora_post_views_read on public.post_views;
create policy tikora_post_views_read on public.post_views for select to authenticated using(user_id=auth.uid() or user_id is null);
drop policy if exists tikora_post_views_insert on public.post_views;
create policy tikora_post_views_insert on public.post_views for insert to authenticated with check(user_id=auth.uid() or user_id is null);
drop policy if exists tikora_calls_participant on public.call_sessions;
create policy tikora_calls_participant on public.call_sessions for all to authenticated using(caller_id=auth.uid() or callee_id=auth.uid()) with check(caller_id=auth.uid() or callee_id=auth.uid());
drop policy if exists tikora_live_owner on public.live_streams;
create policy tikora_live_owner on public.live_streams for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

grant select,insert,update,delete on public.friend_requests,public.blocks,public.saved_posts,public.notifications,public.user_settings,public.story_views,public.reports,public.message_reactions,public.post_shares,public.post_views,public.call_sessions,public.live_streams to authenticated;

-- Realtime for messages. If publication already contains the table, this block does nothing.
do $$ begin
 if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='messages') then
  alter publication supabase_realtime add table public.messages;
 end if;
exception when undefined_object then null;
end $$;
