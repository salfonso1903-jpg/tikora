-- TIKORA: safe additive social features migration
-- Does not drop existing tables or user content.
create extension if not exists pgcrypto;

alter table public.profiles add column if not exists cover_url text;
alter table public.profiles add column if not exists is_private boolean not null default false;
alter table public.profiles add column if not exists updated_at timestamptz default now();

create table if not exists public.friend_requests (
 id uuid primary key default gen_random_uuid(),
 sender_id uuid not null references auth.users(id) on delete cascade,
 receiver_id uuid not null references auth.users(id) on delete cascade,
 status text not null default 'pending' check(status in ('pending','accepted','rejected')),
 created_at timestamptz not null default now(),
 unique(sender_id,receiver_id), check(sender_id <> receiver_id)
);
create table if not exists public.blocks (
 blocker_id uuid not null references auth.users(id) on delete cascade,
 blocked_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now(),
 primary key(blocker_id,blocked_id), check(blocker_id <> blocked_id)
);
create table if not exists public.saved_posts (
 user_id uuid not null references auth.users(id) on delete cascade,
 post_id uuid not null references public.posts(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(user_id,post_id)
);
create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 actor_id uuid references auth.users(id) on delete set null,
 type text not null, reference_id uuid, is_read boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.user_settings (
 user_id uuid primary key references auth.users(id) on delete cascade,
 notifications_enabled boolean not null default true,
 private_account boolean not null default false,
 show_activity boolean not null default true,
 allow_messages boolean not null default true,
 updated_at timestamptz not null default now()
);
create table if not exists public.story_views (
 story_id uuid not null references public.stories(id) on delete cascade,
 viewer_id uuid not null references auth.users(id) on delete cascade,
 viewed_at timestamptz not null default now(), primary key(story_id,viewer_id)
);
create table if not exists public.reports (
 id uuid primary key default gen_random_uuid(),
 reporter_id uuid not null references auth.users(id) on delete cascade,
 reported_user_id uuid references auth.users(id) on delete cascade,
 post_id uuid references public.posts(id) on delete cascade,
 reason text not null, created_at timestamptz not null default now(),
 check(reported_user_id is not null or post_id is not null)
);
create table if not exists public.message_reactions (
 id uuid primary key default gen_random_uuid(),
 message_id uuid not null references public.messages(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 emoji text not null, created_at timestamptz not null default now(), unique(message_id,user_id)
);
create table if not exists public.post_shares (
 id uuid primary key default gen_random_uuid(),
 post_id uuid not null references public.posts(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.post_views (
 id uuid primary key default gen_random_uuid(),
 post_id uuid not null references public.posts(id) on delete cascade,
 user_id uuid references auth.users(id) on delete set null,
 viewed_at timestamptz not null default now()
);

create index if not exists tikora_posts_created_idx on public.posts(created_at desc);
create index if not exists tikora_messages_pair_idx on public.messages(sender_id,receiver_id,created_at desc);
create index if not exists tikora_friend_receiver_idx on public.friend_requests(receiver_id,status,created_at desc);
create index if not exists tikora_notifications_user_idx on public.notifications(user_id,is_read,created_at desc);
create index if not exists tikora_stories_expiry_idx on public.stories(expires_at);

alter table public.friend_requests enable row level security;
alter table public.blocks enable row level security;
alter table public.saved_posts enable row level security;
alter table public.notifications enable row level security;
alter table public.user_settings enable row level security;
alter table public.story_views enable row level security;
alter table public.reports enable row level security;
alter table public.message_reactions enable row level security;
alter table public.post_shares enable row level security;
alter table public.post_views enable row level security;

-- Remove only policies with these migration-specific names before recreating.
drop policy if exists tikora_friend_select_v2 on public.friend_requests;
create policy tikora_friend_select_v2 on public.friend_requests for select to authenticated using(sender_id=auth.uid() or receiver_id=auth.uid());
drop policy if exists tikora_friend_insert_v2 on public.friend_requests;
create policy tikora_friend_insert_v2 on public.friend_requests for insert to authenticated with check(sender_id=auth.uid());
drop policy if exists tikora_friend_update_v2 on public.friend_requests;
create policy tikora_friend_update_v2 on public.friend_requests for update to authenticated using(receiver_id=auth.uid()) with check(receiver_id=auth.uid());
drop policy if exists tikora_friend_delete_v2 on public.friend_requests;
create policy tikora_friend_delete_v2 on public.friend_requests for delete to authenticated using(sender_id=auth.uid() or receiver_id=auth.uid());

drop policy if exists tikora_blocks_select_v2 on public.blocks;
create policy tikora_blocks_select_v2 on public.blocks for select to authenticated using(blocker_id=auth.uid());
drop policy if exists tikora_blocks_insert_v2 on public.blocks;
create policy tikora_blocks_insert_v2 on public.blocks for insert to authenticated with check(blocker_id=auth.uid());
drop policy if exists tikora_blocks_delete_v2 on public.blocks;
create policy tikora_blocks_delete_v2 on public.blocks for delete to authenticated using(blocker_id=auth.uid());

drop policy if exists tikora_saved_select_v2 on public.saved_posts;
create policy tikora_saved_select_v2 on public.saved_posts for select to authenticated using(user_id=auth.uid());
drop policy if exists tikora_saved_insert_v2 on public.saved_posts;
create policy tikora_saved_insert_v2 on public.saved_posts for insert to authenticated with check(user_id=auth.uid());
drop policy if exists tikora_saved_delete_v2 on public.saved_posts;
create policy tikora_saved_delete_v2 on public.saved_posts for delete to authenticated using(user_id=auth.uid());

drop policy if exists tikora_notifications_select_v2 on public.notifications;
create policy tikora_notifications_select_v2 on public.notifications for select to authenticated using(user_id=auth.uid());
drop policy if exists tikora_notifications_update_v2 on public.notifications;
create policy tikora_notifications_update_v2 on public.notifications for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
-- Notification inserts should be performed by trusted server code, not arbitrary clients.

drop policy if exists tikora_settings_select_v2 on public.user_settings;
create policy tikora_settings_select_v2 on public.user_settings for select to authenticated using(user_id=auth.uid());
drop policy if exists tikora_settings_insert_v2 on public.user_settings;
create policy tikora_settings_insert_v2 on public.user_settings for insert to authenticated with check(user_id=auth.uid());
drop policy if exists tikora_settings_update_v2 on public.user_settings;
create policy tikora_settings_update_v2 on public.user_settings for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

drop policy if exists tikora_story_views_select_v2 on public.story_views;
create policy tikora_story_views_select_v2 on public.story_views for select to authenticated using(viewer_id=auth.uid() or exists(select 1 from public.stories s where s.id=story_id and s.user_id=auth.uid()));
drop policy if exists tikora_story_views_insert_v2 on public.story_views;
create policy tikora_story_views_insert_v2 on public.story_views for insert to authenticated with check(viewer_id=auth.uid());

drop policy if exists tikora_reports_insert_v2 on public.reports;
create policy tikora_reports_insert_v2 on public.reports for insert to authenticated with check(reporter_id=auth.uid());
drop policy if exists tikora_reports_select_v2 on public.reports;
create policy tikora_reports_select_v2 on public.reports for select to authenticated using(reporter_id=auth.uid());

drop policy if exists tikora_reactions_select_v2 on public.message_reactions;
create policy tikora_reactions_select_v2 on public.message_reactions for select to authenticated using(exists(select 1 from public.messages m where m.id=message_id and (m.sender_id=auth.uid() or m.receiver_id=auth.uid())));
drop policy if exists tikora_reactions_insert_v2 on public.message_reactions;
create policy tikora_reactions_insert_v2 on public.message_reactions for insert to authenticated with check(user_id=auth.uid() and exists(select 1 from public.messages m where m.id=message_id and (m.sender_id=auth.uid() or m.receiver_id=auth.uid())));
drop policy if exists tikora_reactions_delete_v2 on public.message_reactions;
create policy tikora_reactions_delete_v2 on public.message_reactions for delete to authenticated using(user_id=auth.uid());

drop policy if exists tikora_shares_select_v2 on public.post_shares;
create policy tikora_shares_select_v2 on public.post_shares for select to authenticated using(user_id=auth.uid());
drop policy if exists tikora_shares_insert_v2 on public.post_shares;
create policy tikora_shares_insert_v2 on public.post_shares for insert to authenticated with check(user_id=auth.uid());
drop policy if exists tikora_views_select_v2 on public.post_views;
create policy tikora_views_select_v2 on public.post_views for select to authenticated using(user_id=auth.uid() or exists(select 1 from public.posts p where p.id=post_id and p.user_id=auth.uid()));
drop policy if exists tikora_views_insert_v2 on public.post_views;
create policy tikora_views_insert_v2 on public.post_views for insert to authenticated with check(user_id=auth.uid());

grant select,insert,update,delete on public.friend_requests,public.blocks,public.saved_posts,public.notifications,public.user_settings,public.story_views,public.reports,public.message_reactions,public.post_shares,public.post_views to authenticated;

-- Keep Supabase Auth session persistence enabled by default; phone OTP needs an SMS provider configured in Supabase Auth.
