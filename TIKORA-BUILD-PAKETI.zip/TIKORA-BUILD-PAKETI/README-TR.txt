TIKORA - APK BUILD PAKETI

Bu paket, erişilebilir eski TIKORA web/Capacitor kaynaklarından hazırlanmıştır.

GitHub'a yükleme:
1. ZIP'i çıkarın.
2. İçindeki dosyaların tamamını TIKORA GitHub deposunun kök dizinine yükleyin.
   .github klasörü gizli klasör olarak korunmalıdır.
3. GitHub > Actions > Build TIKORA APK > Run workflow.
4. İşlem yeşil tik ile tamamlanırsa ilgili çalışmanın sayfasında Artifacts bölümünden
   TIKORA-debug-APK dosyasını indirin.

Bu paket içindeki APK iş akışı Capacitor tabanlı mevcut www uygulamasını derler.

ÖNEMLİ KAYNAK SINIRI:
Emergent ortamında daha önce oluşturulduğu konuşmada belirtilen Python/FastAPI ve
React Native/Expo dosyalarının (server.py, r_auth.py, r_stories.py, r_reels.py,
r_notifications.py, r_files.py, r_chat.py, r_users.py, r_posts.py, r_explore.py,
r_admin.py, app/_layout.tsx, app/index.tsx vb.) tam kaynak içerikleri mevcut dosya
arşivlerinde bulunamadı. Dosya adları ve bazı kod parçaları konuşma kayıtlarında
geçiyor; fakat bu eksik içerikler uydurularak bu pakete eklenmedi.

Bu nedenle bu paket APK derleme denemesi içindir; Emergent backend özelliklerinin
tamamının çalıştığı anlamına gelmez. Gerçek backend entegrasyonu için ilgili kaynak
modüllerinin tam içerikleri gerekir.
