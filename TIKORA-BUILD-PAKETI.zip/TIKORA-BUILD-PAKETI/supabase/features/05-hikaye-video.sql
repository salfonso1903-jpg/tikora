-- PAKET 5: Hikâye görüntüleme kaydı. stories tablosunun mevcut olduğu varsayılır.
CREATE TABLE IF NOT EXISTS public.story_views (
 story_id uuid NOT NULL REFERENCES public.stories(id) ON DELETE CASCADE,
 viewer_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 viewed_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(story_id,viewer_id)
);
ALTER TABLE public.story_views ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tikora_storyviews_select ON public.story_views;
CREATE POLICY tikora_storyviews_select ON public.story_views FOR SELECT TO authenticated
 USING(viewer_id=auth.uid() OR EXISTS(SELECT 1 FROM public.stories s WHERE s.id=story_id AND s.user_id=auth.uid()));
DROP POLICY IF EXISTS tikora_storyviews_insert ON public.story_views;
CREATE POLICY tikora_storyviews_insert ON public.story_views FOR INSERT TO authenticated WITH CHECK(viewer_id=auth.uid());
GRANT SELECT,INSERT ON public.story_views TO authenticated;
CREATE INDEX IF NOT EXISTS tikora_story_expiry_idx ON public.stories(expires_at);
-- Video akışı mevcut posts.media_type='video' kayıtlarını kullanır; özel video sunucusu/CDN bu SQL ile kurulmaz.
