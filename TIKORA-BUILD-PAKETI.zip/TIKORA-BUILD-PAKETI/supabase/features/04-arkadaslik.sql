-- PAKET 4: Takip mevcut follows tablosunda; arkadaşlık istekleri ve engelleme eklenir.
CREATE TABLE IF NOT EXISTS public.friend_requests (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 sender_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 receiver_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 status text NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','accepted','rejected')),
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(sender_id,receiver_id), CHECK(sender_id<>receiver_id)
);
CREATE TABLE IF NOT EXISTS public.blocks (
 blocker_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 blocked_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(blocker_id,blocked_id), CHECK(blocker_id<>blocked_id)
);
ALTER TABLE public.friend_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blocks ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tikora_friend_select ON public.friend_requests;
CREATE POLICY tikora_friend_select ON public.friend_requests FOR SELECT TO authenticated USING(sender_id=auth.uid() OR receiver_id=auth.uid());
DROP POLICY IF EXISTS tikora_friend_insert ON public.friend_requests;
CREATE POLICY tikora_friend_insert ON public.friend_requests FOR INSERT TO authenticated WITH CHECK(sender_id=auth.uid());
DROP POLICY IF EXISTS tikora_friend_update ON public.friend_requests;
CREATE POLICY tikora_friend_update ON public.friend_requests FOR UPDATE TO authenticated USING(receiver_id=auth.uid()) WITH CHECK(receiver_id=auth.uid());
DROP POLICY IF EXISTS tikora_block_select ON public.blocks;
CREATE POLICY tikora_block_select ON public.blocks FOR SELECT TO authenticated USING(blocker_id=auth.uid());
DROP POLICY IF EXISTS tikora_block_insert ON public.blocks;
CREATE POLICY tikora_block_insert ON public.blocks FOR INSERT TO authenticated WITH CHECK(blocker_id=auth.uid());
DROP POLICY IF EXISTS tikora_block_delete ON public.blocks;
CREATE POLICY tikora_block_delete ON public.blocks FOR DELETE TO authenticated USING(blocker_id=auth.uid());
GRANT SELECT,INSERT,UPDATE,DELETE ON public.friend_requests TO authenticated;
GRANT SELECT,INSERT,DELETE ON public.blocks TO authenticated;
CREATE INDEX IF NOT EXISTS tikora_friend_receiver_idx ON public.friend_requests(receiver_id,status,created_at DESC);
