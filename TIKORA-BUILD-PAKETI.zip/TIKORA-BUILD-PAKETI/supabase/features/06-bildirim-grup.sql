-- PAKET 6: Bildirim kaydı, grup sohbeti, şikâyetler
CREATE TABLE IF NOT EXISTS public.notifications (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 actor_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
 type text NOT NULL, reference_id uuid, is_read boolean NOT NULL DEFAULT false,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.reports (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 reporter_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 reported_user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
 post_id uuid REFERENCES public.posts(id) ON DELETE CASCADE,
 reason text NOT NULL, created_at timestamptz NOT NULL DEFAULT now(),
 CHECK(reported_user_id IS NOT NULL OR post_id IS NOT NULL)
);
CREATE TABLE IF NOT EXISTS public.chat_groups (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL,
 created_by uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.group_members (
 group_id uuid NOT NULL REFERENCES public.chat_groups(id) ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 role text NOT NULL DEFAULT 'member', joined_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY(group_id,user_id)
);
CREATE TABLE IF NOT EXISTS public.group_messages (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 group_id uuid NOT NULL REFERENCES public.chat_groups(id) ON DELETE CASCADE,
 sender_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 body text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.group_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.group_messages ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tikora_notif_select ON public.notifications;
CREATE POLICY tikora_notif_select ON public.notifications FOR SELECT TO authenticated USING(user_id=auth.uid());
DROP POLICY IF EXISTS tikora_notif_update ON public.notifications;
CREATE POLICY tikora_notif_update ON public.notifications FOR UPDATE TO authenticated USING(user_id=auth.uid()) WITH CHECK(user_id=auth.uid());
DROP POLICY IF EXISTS tikora_report_insert ON public.reports;
CREATE POLICY tikora_report_insert ON public.reports FOR INSERT TO authenticated WITH CHECK(reporter_id=auth.uid());
DROP POLICY IF EXISTS tikora_group_members_select ON public.group_members;
CREATE POLICY tikora_group_members_select ON public.group_members FOR SELECT TO authenticated USING(user_id=auth.uid());
DROP POLICY IF EXISTS tikora_group_members_insert ON public.group_members;
CREATE POLICY tikora_group_members_insert ON public.group_members FOR INSERT TO authenticated WITH CHECK(user_id=auth.uid());
DROP POLICY IF EXISTS tikora_group_messages_select ON public.group_messages;
CREATE POLICY tikora_group_messages_select ON public.group_messages FOR SELECT TO authenticated USING(EXISTS(SELECT 1 FROM public.group_members gm WHERE gm.group_id=group_messages.group_id AND gm.user_id=auth.uid()));
DROP POLICY IF EXISTS tikora_group_messages_insert ON public.group_messages;
CREATE POLICY tikora_group_messages_insert ON public.group_messages FOR INSERT TO authenticated WITH CHECK(sender_id=auth.uid() AND EXISTS(SELECT 1 FROM public.group_members gm WHERE gm.group_id=group_messages.group_id AND gm.user_id=auth.uid()));
GRANT SELECT,UPDATE ON public.notifications TO authenticated;
GRANT INSERT ON public.reports TO authenticated;
GRANT SELECT,INSERT ON public.chat_groups,public.group_members,public.group_messages TO authenticated;
CREATE INDEX IF NOT EXISTS tikora_notifications_user_idx ON public.notifications(user_id,is_read,created_at DESC);
CREATE INDEX IF NOT EXISTS tikora_group_messages_idx ON public.group_messages(group_id,created_at DESC);
-- Bildirim kayıtlarını istemciden herkese açık biçimde eklemeyin; güvenilir sunucu fonksiyonu kullanın.
