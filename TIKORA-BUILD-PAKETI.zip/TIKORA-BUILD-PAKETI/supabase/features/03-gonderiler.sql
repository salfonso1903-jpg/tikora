-- PAKET 3: Gönderi kaydetme, paylaşım ve görüntülenme kayıtları
CREATE TABLE IF NOT EXISTS public.saved_posts (
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 post_id uuid NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
 created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(user_id,post_id)
);
CREATE TABLE IF NOT EXISTS public.post_shares (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 post_id uuid NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.post_views (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 post_id uuid NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
 user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
 viewed_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.saved_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.post_shares ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.post_views ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tikora_saved_select ON public.saved_posts;
CREATE POLICY tikora_saved_select ON public.saved_posts FOR SELECT TO authenticated USING(user_id=auth.uid());
DROP POLICY IF EXISTS tikora_saved_insert ON public.saved_posts;
CREATE POLICY tikora_saved_insert ON public.saved_posts FOR INSERT TO authenticated WITH CHECK(user_id=auth.uid());
DROP POLICY IF EXISTS tikora_saved_delete ON public.saved_posts;
CREATE POLICY tikora_saved_delete ON public.saved_posts FOR DELETE TO authenticated USING(user_id=auth.uid());
DROP POLICY IF EXISTS tikora_shares_select ON public.post_shares;
CREATE POLICY tikora_shares_select ON public.post_shares FOR SELECT TO authenticated USING(user_id=auth.uid());
DROP POLICY IF EXISTS tikora_shares_insert ON public.post_shares;
CREATE POLICY tikora_shares_insert ON public.post_shares FOR INSERT TO authenticated WITH CHECK(user_id=auth.uid());
DROP POLICY IF EXISTS tikora_views_insert ON public.post_views;
CREATE POLICY tikora_views_insert ON public.post_views FOR INSERT TO authenticated WITH CHECK(user_id=auth.uid());
GRANT SELECT,INSERT,DELETE ON public.saved_posts TO authenticated;
GRANT SELECT,INSERT ON public.post_shares,public.post_views TO authenticated;
