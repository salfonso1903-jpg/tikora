-- PAKET 1: Mesajlaşma için ek alanlar ve mesaj tepkileri
-- Mevcut messages tablosunu silmez. Önce mevcut sütunlarla uyumluluğu kontrol edin.
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS read_at timestamptz;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS edited_at timestamptz;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS media_url text;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS media_type text;
CREATE INDEX IF NOT EXISTS tikora_messages_sender_time_idx ON public.messages(sender_id, created_at DESC);
CREATE INDEX IF NOT EXISTS tikora_messages_receiver_time_idx ON public.messages(receiver_id, created_at DESC);
CREATE TABLE IF NOT EXISTS public.message_reactions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 message_id uuid NOT NULL REFERENCES public.messages(id) ON DELETE CASCADE,
 user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
 emoji text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(message_id,user_id)
);
ALTER TABLE public.message_reactions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tikora_msgreact_select ON public.message_reactions;
CREATE POLICY tikora_msgreact_select ON public.message_reactions FOR SELECT TO authenticated
 USING (EXISTS (SELECT 1 FROM public.messages m WHERE m.id=message_id AND (m.sender_id=auth.uid() OR m.receiver_id=auth.uid())));
DROP POLICY IF EXISTS tikora_msgreact_insert ON public.message_reactions;
CREATE POLICY tikora_msgreact_insert ON public.message_reactions FOR INSERT TO authenticated
 WITH CHECK (user_id=auth.uid() AND EXISTS (SELECT 1 FROM public.messages m WHERE m.id=message_id AND (m.sender_id=auth.uid() OR m.receiver_id=auth.uid())));
DROP POLICY IF EXISTS tikora_msgreact_delete ON public.message_reactions;
CREATE POLICY tikora_msgreact_delete ON public.message_reactions FOR DELETE TO authenticated USING(user_id=auth.uid());
GRANT SELECT,INSERT,DELETE ON public.message_reactions TO authenticated;
