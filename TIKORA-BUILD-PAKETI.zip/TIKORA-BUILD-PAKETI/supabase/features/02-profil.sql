-- PAKET 2: Profil alanları ve hesap ayarları
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS cover_url text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS bio text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS website text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS location text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_private boolean NOT NULL DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE TABLE IF NOT EXISTS public.user_settings (
 user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
 notifications_enabled boolean NOT NULL DEFAULT true,
 private_account boolean NOT NULL DEFAULT false,
 show_activity boolean NOT NULL DEFAULT true,
 allow_messages boolean NOT NULL DEFAULT true,
 updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tikora_user_settings_select ON public.user_settings;
CREATE POLICY tikora_user_settings_select ON public.user_settings FOR SELECT TO authenticated USING(user_id=auth.uid());
DROP POLICY IF EXISTS tikora_user_settings_insert ON public.user_settings;
CREATE POLICY tikora_user_settings_insert ON public.user_settings FOR INSERT TO authenticated WITH CHECK(user_id=auth.uid());
DROP POLICY IF EXISTS tikora_user_settings_update ON public.user_settings;
CREATE POLICY tikora_user_settings_update ON public.user_settings FOR UPDATE TO authenticated USING(user_id=auth.uid()) WITH CHECK(user_id=auth.uid());
GRANT SELECT,INSERT,UPDATE ON public.user_settings TO authenticated;
