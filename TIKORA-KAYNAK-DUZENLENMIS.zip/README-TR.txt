TIKORA - GUNCELLENMIS KAYNAK PAKETI

Bu paket mevcut TIKORA projesinin uzerine eklenmistir; eski kullanici/gonderi tablolari silinmez.

DOSYALAR
- www/index.html: telefon OTP ve ayarlar arayuzu eklendi
- www/app.js: telefon SMS kodu gonderme/dogrulama, oturum devam ettirme (Supabase Auth), ayar kaydetme ve engel kaldirma arayuzu
- www/style.css: yeni arayuz stilleri
- supabase-upgrade.sql: ek sosyal ozellik tablolarinin guvenlik politikalarini ve indekslerini ekler
- supabase.sql: onceki temel hikaye/storage kurulumu

KURULUM
1) Supabase SQL Editor > New Query ac.
2) supabase-upgrade.sql dosyasinin TAMAMINI yapistirip Run yap.
3) GitHub deposundaki mevcut www/index.html, www/app.js, www/style.css dosyalarini bu pakettekilerle degistir.
4) Commit changes yap.
5) GitHub Actions > Build TIKORA APK > Run workflow.
6) SMS icin Supabase Dashboard > Authentication > Providers > Phone bolumunde SMS saglayicisini ve OTP ayarlarini yapilandir. SMS servisi baglanmadan kod telefona gelmez.

DOGRULANANLAR
- app.js JavaScript syntax kontrolunden gecti.
- Paket mevcut proje yapisini ve Capacitor APK workflow dosyasini korur.

ONEMLI SINIRLAR
- E-posta kaydi/girisi ve Supabase oturumunu geri yukleme mevcut projede vardir.
- Bu guncelleme telefon OTP akisini ekler; SMS'in calismasi Supabase SMS saglayici ayarina baglidir.
- Kullanici adi ile giris, e-posta adresini guvenli bicimde cozen sunucu tarafi kimlik dogrulama gerektirir; bu pakette etkinlestirilmis degildir.
- Grup sohbeti, sesli/goruntulu arama, canli yayin, push bildirim ve Reels icin ek sunucu/gercek zamanli medya servisleri gerekir; bu pakette tamamlanmis gibi sunulmaz.
- Arkadaslik istekleri, engelleme, kaydedilen gonderiler, bildirim kayitlari, hikaye goruntuleme, ayarlar, sikayet, mesaj tepkileri, paylasim ve goruntulenme icin SQL altyapisi eklenmistir. Bunlarin tumu icin kullanici arayuzu henuz tamamlanmis degildir.

Performans: mevcut akislardaki limitler korunmustur; video preload metadata kullanir. Buyuk olcekli canli sistem icin ayrica pagination, video CDN/transcoding ve rate-limit gerekir.
