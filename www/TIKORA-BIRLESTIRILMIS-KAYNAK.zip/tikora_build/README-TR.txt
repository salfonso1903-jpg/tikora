TIKORA - BIRLESTIRILMIS KAYNAK GUNCELLEMESI

Bu paket mevcut TIKORA kaynaklarini temel alir. Mevcut kullanici verilerini silen bir islem icermez.

Bu pakette duzeltilen istemci davranislari:
- Akis gonderilerinde kullanicinin mevcut begeni durumu yuklenir.
- Begen butonu basildiginda kalp aninda kirmizi olur; geri alindiginda eski haline doner.
- Kullanici arama sonuclarinda takip edilen hesaplarin butonu "Takip ediliyor" olarak gosterilir.
- Takip et/birak islemi sonrasinda buton metni aninda guncellenir.
- Acik sohbet icin gelen ve giden mesaj degisiklikleri dinlenir.

ONEMLI: Bunlar istemci kodu duzeltmeleridir. Supabase tablo/kolon adlari, RLS politikalari, Storage bucket ve Realtime ayarlari mevcut projenin semasiyla uyumlu olmalidir.

SMS: Supabase Dashboard > Authentication > Providers > Phone etkinlestirilmeli; SMS saglayicisi ve mesaj sablonu ayarlanmalidir. Bu ayarlar olmadan SMS kodu gonderilemez.

Sesli/goruntulu arama ve canli yayin bu pakette etkinlestirilmis degildir. Bunlar icin WebRTC/signaling, TURN sunucusu, yayin altyapisi, izinler ve ek servis kurulumu gerekir. Bildirimlerin otomatik uretilmesi icin guvenilir sunucu/Edge Function tetikleyicileri gerekir.

Kurulum: Bu kaynaklar, mevcut GitHub derleme akisinin bekledigi ZIP yapisiyla paketlenmistir. Eski APK'yi ve mevcut kaynak ZIP'lerini yedekleyin. Once test projesinde deneyin. SQL dosyalarini mevcut sema kontrol edilmeden tekrar calistirmayin.
