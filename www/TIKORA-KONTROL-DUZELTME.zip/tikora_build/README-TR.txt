TIKORA - DUZELTILMIS KAYNAK PAKETI

Bu paket mevcut TIKORA kaynaklarinin guvenli bir kopyasindan uretilmistir.
Eski APK veya GitHub deposundaki dosyalar otomatik olarak degistirilmez.

BU PAKETTE YAPILAN SOMUT DUZELTME
- index.html icinde bulunmayan likesBtn ogesine app.js tarafinda dogrudan olay baglanmasi kaldirildi. Bu hata uygulama baslangicinda JavaScript'in durmasina neden olabiliyordu.
- Supabase JS veya config eksikse ekranda acik kurulum hatasi gosterilir.
- Bildirim zilinin ekran acma olayi bagli.

ONEMLI
Bu paket tam Instagram esdegeri veya butun ozellikleri test edilmis son APK degildir.
Kaynakta temel e-posta kayit/giris, profil, gonderi, medya yukleme, hikaye, kesfet ve birebir mesaj kodlari bulunur.
SMS, gercek zamanli mesaj, bildirimler, arkadaslik, kaydetme, grup sohbeti, arama, canli yayin ve push bildirimleri icin Supabase servisleri, tablo semalari ve cihaz testleri gerekir.
SQL dosyalarini calistirmadan once mevcut veritabaninin yedegini alin. SQL'i dogrudan calistirmak mevcut tablo semalariyla uyumsuzluk olusturabilir.
Supabase SMS saglayicisi ayarlanmadan SMS kodu gonderilemez.

APK olusturma:
1. Bu kaynak paketin icerigini GitHub reposunun dogru kaynak dizinine kopyalayin; eski dosyalarin yedegini alin.
2. Supabase ayarlarini www/config.js icinde dogrulayin.
3. GitHub Actions build-apk.yml islemini calistirin.
4. APK'yi kurmadan once onceki APK'yi telefonda saklayin ve ayri test edin.

Test durumu:
- JavaScript sozdizimi kontrolu: yapilacak.
- Supabase canli baglanti ve RLS: bu ortamdan dogrulanamadi.
- Android APK derlemesi ve fiziksel cihaz testi: bu ortamda yapilmadi.
