create table if not exists public.stories (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 media_url text not null,
 media_type text not null check (media_type in ('image','video')),
 created_at timestamptz not null default now(),
 expires_at timestamptz not null default (now() + interval '24 hours')
);
alter table public.stories enable row level security;
grant select,insert,delete on public.stories to authenticated;
drop policy if exists tikora_stories_read on public.stories;
create policy tikora_stories_read on public.stories for select to authenticated using (expires_at > now());
drop policy if exists tikora_stories_insert on public.stories;
create policy tikora_stories_insert on public.stories for insert to authenticated with check (user_id = auth.uid());
drop policy if exists tikora_stories_delete on public.stories;
create policy tikora_stories_delete on public.stories for delete to authenticated using (user_id = auth.uid());

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('media','media',true,104857600,array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime'])
on conflict (id) do update set public=true,file_size_limit=104857600;
drop policy if exists tikora_media_read on storage.objects;
create policy tikora_media_read on storage.objects for select to public using (bucket_id='media');
drop policy if exists tikora_media_upload on storage.objects;
create policy tikora_media_upload on storage.objects for insert to authenticated with check (bucket_id='media');
drop policy if exists tikora_media_delete on storage.objects;
create policy tikora_media_delete on storage.objects for delete to authenticated using (bucket_id='media' and owner_id=auth.uid()::text);
