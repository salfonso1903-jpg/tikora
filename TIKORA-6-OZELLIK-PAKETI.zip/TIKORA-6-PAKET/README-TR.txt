TIKORA - 6 AYRI ÖZELLİK PAKETİ

Bu arşiv, konuştuğumuz altı özelliğin veritabanı SQL paketlerini ayrı dosyalara ayırır.

KLASÖRLER
01-mesajlasma/database.sql       Mesaj alanları, mesaj tepkileri
02-profil/database.sql           Profil alanları, hesap ayarları
03-gonderiler/database.sql       Kaydetme, paylaşım, görüntülenme kayıtları
04-arkadaslik/database.sql       Arkadaşlık isteği, engelleme (takip için mevcut follows kullanılır)
05-hikaye-video/database.sql     Hikâye görüntüleme kayıtları
06-bildirim-grup/database.sql    Bildirim, şikâyet ve grup sohbeti tabloları
mevcut-www/                     İncelenen kaynak paketteki mevcut web dosyalarının kopyası

ÖNEMLİ KURULUM NOTU
- Bu altı SQL dosyasını tek seferde çalıştırmayın. Önce veritabanı yedeği alın.
- Her dosyayı Supabase SQL Editor > New query alanında ayrı ayrı çalıştırıp sonucu kontrol edin.
- Paketler mevcut tabloları DROP etmez; bazıları mevcut profiles/posts/messages/stories şemasının bulunduğunu varsayar.
- Paket 1, messages tablosunda id, sender_id, receiver_id, created_at sütunlarının bulunduğunu varsayar.
- Paket 3, posts tablosunda uuid türünde id bulunduğunu varsayar.
- Paket 5, stories tablosunun daha önce kurulduğunu varsayar.
- Grup sohbeti RLS politikaları temel üyelik kontrolü sağlar; grup oluşturma ve üye davet etme için ayrıca güvenli sunucu/uygulama akışı gerekir.

ÇOK ÖNEMLİ: Bu ZIP, altı veritabanı paketini ve mevcut web kaynaklarının kopyasını içerir. Altı özelliğin tamamının kullanıcı arayüzü ve uygulama JavaScript entegrasyonu tamamlanmış değildir. SQL çalıştırmak tek başına uygulama ekranlarını/işlevlerini etkinleştirmez. Bu nedenle bu arşivi yüklemekle yeni APK'nın tüm özellikleri çalışır hale gelmez. Önce SQL paketlerini kontrollü biçimde kurup sonra her özelliğin www/app.js ve www/index.html entegrasyonunu yapıp test etmek gerekir.

GÜVENLİK
- Supabase service_role anahtarını asla uygulamaya veya GitHub'a koymayın.
- Bildirim oluşturma gibi güvenilir işlemler sunucu tarafında yapılmalıdır.
- SMS, push bildirim, sesli/görüntülü arama ve canlı yayın ek sağlayıcı/servis yapılandırması ister.
