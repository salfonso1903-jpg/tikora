TIKORA kaynak paketi
1) Supabase SQL Editor'de supabase.sql dosyasının tamamını çalıştır.
2) Projeyi GitHub deposuna yükle.
3) Actions > Build TIKORA APK > Run workflow ile APK derle.
4) Derleme bitince Artifacts içinden TIKORA-APK indir.
